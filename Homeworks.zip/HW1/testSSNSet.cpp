//#include "SSNSet.h"
//#include <iostream>
//#include <cassert>
//using namespace std;
//
//int main()
//{
//    SSNSet s;
//    assert(s.size() == 0);
//    assert(s.add(1001) && s.size() == 1);
//    s.print(); //expect 1001
//    assert(! s.add(1001) && s.size() == 1);
//    assert(s.add(01) && s.size() == 2);
//    s.print(); //expect 1001\n01
//    SSNSet s2 = s;
//    s2.print();
//    s = s;
//    s.print();
//    cout << "All Tests Passed" << endl;
//}
//
